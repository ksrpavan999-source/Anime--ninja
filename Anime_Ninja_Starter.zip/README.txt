ANIME NINJA — Version 1 starter website
========================================

Files
-----
index.html — complete responsive website (HTML, CSS, and JavaScript in one file).

How to test on your phone
-------------------------
1. Download and extract the ZIP.
2. Open index.html in a browser. If your phone's file viewer will not open it, upload the file to a free static host (see below).
3. Try search, genre filters, sorting, opening an anime, the demo player, and the heart favorites.
4. Favorites are saved locally in the browser on that device.

Free publishing options
-----------------------
For a beginner using a phone, Netlify Drop is a simple option:
1. Open https://app.netlify.com/drop in your browser.
2. If required, create a free account.
3. Upload the extracted folder or a ZIP containing index.html (follow the current on-screen instructions).
4. Netlify will provide a public website address.

Alternative: GitHub Pages can host a static site from a repository.

Important limitations
---------------------
- This is a front-end starter/prototype. It has no real account system, database, Google login, admin dashboard, cross-device sync, browser push notifications, or actual episode library yet.
- Favorites use localStorage and stay on this browser/device.
- The player uses a generic CC0 sample video only to demonstrate playback. It is NOT an anime episode. Replace it only with video content you own or have permission to stream.
- Anime names are sample catalog entries; original CSS artwork is used instead of copyrighted poster images.
- Metadata APIs do not provide rights to stream full episodes. Only add authorized videos.
- Hosting can be free for a static demo, but databases, authentication, video storage, bandwidth, or a custom domain may have limits or costs.
